# For Readers and Developers

Thanks for reading PaddlePaddle documentation. 

Since **September 17th, 2018**, the **0.15.0 and develop** documentation source has been moved to [FluidDoc Repo](https://github.com/PaddlePaddle/FluidDoc) and updated there.

Please turn to FluidDoc Repo for the latest documentation.
